# File Index — Assembly & Static Build Central Spine (Dev Review)

Generated: 2026-11-18 18:25 UTC

Extensions `.ts`, `.tsx`, `.js`, `.mjs`, `.sh`, `.html` have been renamed
to `<name>.txt` so the archive passes corporate email filters.
See `RESTORE_EXTENSIONS.txt` for the one-line PowerShell restore command.

| Zip path | Original extension |
|---|---|
| `src/App.tsx.txt` | `.tsx` |
| `src/components/CellsZones.tsx.txt` | `.tsx` |
| `src/components/DataTable.tsx.txt` | `.tsx` |
| `src/components/DualViewLayoutCard.tsx.txt` | `.tsx` |
| `src/components/ExcelImportModal.tsx.txt` | `.tsx` |
| `src/components/ExecutiveRiskCards.tsx.txt` | `.tsx` |
| `src/components/FpdRegistry.tsx.txt` | `.tsx` |
| `src/components/GateRow.tsx.txt` | `.tsx` |
| `src/components/LabourGanttCard.tsx.txt` | `.tsx` |
| `src/components/LayoutEditor.tsx.txt` | `.tsx` |
| `src/components/LayoutFloorHeader.tsx.txt` | `.tsx` |
| `src/components/LayoutShapeTable.tsx.txt` | `.tsx` |
| `src/components/LayoutSvgCanvas.tsx.txt` | `.tsx` |
| `src/components/LayoutToolbar.tsx.txt` | `.tsx` |
| `src/components/QuickStartStrip.tsx.txt` | `.tsx` |
| `src/components/SpineFilterBar.tsx.txt` | `.tsx` |
| `src/components/TabNav.tsx.txt` | `.tsx` |
| `src/components/TopBar.tsx.txt` | `.tsx` |
| `src/components/common/Cards.tsx.txt` | `.tsx` |
| `src/components/common/EngineeringTooltip.tsx.txt` | `.tsx` |
| `src/components/common/FormInputs.tsx.txt` | `.tsx` |
| `src/components/common/MultiSelectPicker.tsx.txt` | `.tsx` |
| `src/components/common/RagBadge.tsx.txt` | `.tsx` |
| `src/components/common/SlideOverDrawer.tsx.txt` | `.tsx` |
| `src/components/common/index.ts.txt` | `.ts` |
| `src/components/primitives.tsx.txt` | `.tsx` |
| `src/data/guides.ts.txt` | `.ts` |
| `src/data/seed.ts.txt` | `.ts` |
| `src/engine/formulas/activityMetrics.ts.txt` | `.ts` |
| `src/engine/formulas/calendarAndLearning.ts.txt` | `.ts` |
| `src/engine/formulas/cpmScheduler.ts.txt` | `.ts` |
| `src/engine/formulas/index.ts.txt` | `.ts` |
| `src/engine/formulas/liftPhysics.ts.txt` | `.ts` |
| `src/engine/formulas/resourceDuty.ts.txt` | `.ts` |
| `src/engine/gates.ts.txt` | `.ts` |
| `src/engine/integrity.ts.txt` | `.ts` |
| `src/engine/model.test.ts.txt` | `.ts` |
| `src/engine/model.ts.txt` | `.ts` |
| `src/engine/space.ts.txt` | `.ts` |
| `src/engine/testFixture.ts.txt` | `.ts` |
| `src/engine/validation/index.ts.txt` | `.ts` |
| `src/engine/validation/releaseGates.ts.txt` | `.ts` |
| `src/engine/validation/routeToGreen.ts.txt` | `.ts` |
| `src/engine/validation/summaryExport.ts.txt` | `.ts` |
| `src/index.css` | — |
| `src/lib/excel.ts.txt` | `.ts` |
| `src/lib/excelBopImport.ts.txt` | `.ts` |
| `src/lib/excelExport.ts.txt` | `.ts` |
| `src/lib/excelHelpers.ts.txt` | `.ts` |
| `src/lib/excelImport.ts.txt` | `.ts` |
| `src/lib/format.ts.txt` | `.ts` |
| `src/lib/geometry.ts.txt` | `.ts` |
| `src/lib/imageProcessing.ts.txt` | `.ts` |
| `src/lib/persistence.ts.txt` | `.ts` |
| `src/main.tsx.txt` | `.tsx` |
| `src/store.tsx.txt` | `.tsx` |
| `src/tabs/OperationMethodDrawer.tsx.txt` | `.tsx` |
| `src/tabs/Tab1Targets.tsx.txt` | `.tsx` |
| `src/tabs/Tab2Bop.tsx.txt` | `.tsx` |
| `src/tabs/Tab3Equipment.tsx.txt` | `.tsx` |
| `src/tabs/Tab4Lifts.tsx.txt` | `.tsx` |
| `src/tabs/Tab5Pfmea.tsx.txt` | `.tsx` |
| `src/tabs/Tab6Labour.tsx.txt` | `.tsx` |
| `src/tabs/Tab7Footprint.tsx.txt` | `.tsx` |
| `src/tabs/Tab8Utilisation.tsx.txt` | `.tsx` |
| `src/tabs/Tab9Executive.tsx.txt` | `.tsx` |
| `src/types/bop.ts.txt` | `.ts` |
| `src/types/constants.ts.txt` | `.ts` |
| `src/types/index.ts.txt` | `.ts` |
| `src/types/layout.ts.txt` | `.ts` |
| `src/types/pfmea.ts.txt` | `.ts` |
| `src/types/registry.ts.txt` | `.ts` |
| `src/types/workspace.ts.txt` | `.ts` |
| `src/vite-env.d.ts.txt` | `.ts` |
| `docs/ARCHITECTURE.md` | — |
| `docs/index.html.txt` | `.html` |
| `package.json` | — |
| `tsconfig.json` | — |
| `README.md` | — |
| `CLAUDE.md` | — |
| `Claude.md` | — |
| `CONTRIBUTING.md` | — |
